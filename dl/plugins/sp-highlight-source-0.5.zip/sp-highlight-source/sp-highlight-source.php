<?php
/*
Plugin Name: SP Code Highlight
Plugin URI: http://top-frog.com
Description: Highlight code with Pear Text/Hightligher for WordPress 2.6+
Version: .5
Author: Shawn Parker
Author URI: http://top-frog.com 
*/


function sph_init() {
	@include('Text/Highlighter.php');
	if(class_exists('Text_Highlighter')) {
		wp_enqueue_style('highlight',WP_PLUGIN_URL.'/sp-highlight-source/css/highlight.css',array(),'.5','all');
		wp_enqueue_script('jquery');
		add_action('wp_footer','sph_highlight_js',10);
		add_filter('the_content','sph_highlight',999);
		add_filter('the_excerpt','sph_highlight',999);		
	}
	elseif(!class_exists('Text_Highlighter') && is_admin()) {
		add_action('admin_notices','sph_admin_message');
	}
}
add_action('init','sph_init');

function sph_admin_message() {
	echo '
		<div id="sph-message" class="updated fade">
			<p style="line-height: 1.3em;"><b>Source highlighting could not be enabled because the "<code>Text_Highlighter</code>" Pear class is not available.</b> Please install "<code>Text_Highlighter</code>" and its dependencies via Pear to use this plugin. This plugin does not, and will not in the forseeable future, work without this dependency.</p>
		</div>
		';
}

function sph_highlight_js() {
	echo '
		<script type="text/javascript">
			//<![CDATA[
				jQuery(function() {
					jQuery("div.hl-wrapper").hover(function(){
							_this = jQuery(this);
							_this.animate({width:jQuery("div.hl-main",_this).width()+"px"});
						},function(){
							jQuery(this).animate({width:"100%"});
						});
					});
			//]]>
		</script>
		';
}

function sph_highlight($content) {
	preg_match_all('/<p><code class="(.*?)">(.*?)<\/code><\/p>/si', $content, $matches);
	if(is_array($matches[0]) && count($matches[0])) {
		foreach($matches[0] as $key => $value) {
			$content = str_replace($matches[0][$key],'<div class="hl-wrapper">'.sph_do_highlight(strip_tags($matches[2][$key]),$matches[1][$key]).'</div>',$content);
		}
	}
	return $content;
}


function sph_do_highlight($content,$type="html") {
	static $sph_highlighters = array();
	$type = strtolower($type);
	
	$types = array(
		'abap' => 'ABAP',
		'java' => 'JAVA',
		'cpp' => 'CPP',
		'diff' => 'DIFF',
		'dtd' => 'DTD',
		'js' => 'JAVASCRIPT',
		'javascript' => 'JAVASCRIPT',
		'php' => 'PHP',
		'phps' => 'PHP',
		'css' => 'CSS',
		'xml' => 'XML',
		'sql' => 'SQL',
		'py' => 'PYTHON',
		'htm' => 'HTML',
		'html' => 'HTML',
		'shtml' => 'HTML',
		'rb' => 'RUBY',
		'pl' => 'PERL',
		'cgi' => 'PERL',
		'sh' => 'SQL' // not perfect, but it looks the best
	);
	
	if(!array_key_exists($type, $types)) { 
		$type = 'html';
	}
	
	if(!array_key_exists($type, $sph_highlighters)) {
		$th = $sph_highlighters[$type] =& Text_Highlighter::factory($types[$type],array('numbers' => HL_NUMBERS_LI));
	}
	else {
		$th = $sph_highlighters[$type];
	}
	
	return $th->highlight(html_entity_decode($content));
}

?>