=== SP Highlight Source ===
Contributors: Shawn Parker
Link: http://top-frog.com/projects/sp-highlight-source
Tags: source code highlight
Requires at least: 2.6
Tested up to: 2.8
Stable tag: .5

This is a source code highlighting plugin for WordPress 2.6+


=== Description ===

The SP Highlight Source plugin is designed to provide a robust, yet flexible, source code highlighting solution for WordPress. It provides source code highlighting for ABAP, C++ (CPP), CSS, DIFF, DTD, HTML, JAVA, Javascript, MySQL, Perl, PHP, Python, Ruby, sh, SQL, and XML. The source is also truncated by default to fit the content width of the standard layout and modified via javascript to expand and show the entire contents when the user's mouse enters the code list area.

Unfortunately the best highlighting package that I've found is provided through Pear so the places this plugin can be used is probably severely limited.


=== Installation ===

**Note:** If you have any doubts about the availability of Pear on your server or if you have enough permissions on your server to install Pear packages then you should contact your hosting provider before installing this plugin. See the FAQ section below for help on how to address your hosting provider in the event you need to ask for their help.

1. Upload the sp-highlight-source folder to your WordPress' plugins folder. This plugin also works on WordPress MU in the mu-plugins folder.
2. Activate the plugin through the Plugins page in the WordPress Admin
3. When writing a post or page, wrap your source code inside `<code class="type">...</code>` tags where `type` is the language type presented within the code block. Make sure your source code's `<` and `>` entities have been encoded to `&lt;` and `&gt;` to prevent them from rendering in the final HTML output.


=== Frequently Asked Questions ===

= How do I install Pear or the Text_Highlighter Pear Package? = 

Installation of Pear and/or its packages is beyond the scope of this document. Please reference the [Pear documentation](http://pear.php.net/manual/en/installation.php) for information on how to work with Pear. Don't worry, its not that bad.

= I don't have access to the command line on my server = 

Contact your hosting provider to see if they can grant you rights to install Pear packages or if they can install packages for you. In shared hosting environments it may not be allowed or they may want to examine the desired package first to make sure that its not going to cause problems with other hosted sites on the server. Text_Highlighter is a pretty innocuous package so there's a reasonable chance that they might install it for you. Feel free to point the tech or service rep to this download package as well to help them understand what you're wanting to accomplish.


=== Screenshots ===

N/A


=== Changelog ===

= .5 =
* initial release